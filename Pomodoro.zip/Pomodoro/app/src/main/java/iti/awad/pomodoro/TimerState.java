package iti.awad.pomodoro;

public enum TimerState {
    Running, Paused, Stopped
}
